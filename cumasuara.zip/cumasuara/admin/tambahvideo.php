<!DOCTYPE html>
<html lang="en">
	<head>
	    <meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta name="description" content="">
	    <meta name="author" content="">
	    <title>Tambah Video</title>
	    <link href="../assert/css/bootstrap.min.css" rel="stylesheet">
	    <link href="../assert/css/jumbotron-narrow.css" rel="stylesheet">
		<script src="../assert/js/jquery.min.js"></script>
	</head>
  	<body>
    <div class="container">
	 
	 <form method="POST" action='pengaturan_video.php'>
        	<label for="exampleInputEmail1" style="text-align: left;">
			<span class="glyphicon glyphicon-credit-card">&nbsp;</span>Nama Video</label> 
        	<input type="text" class="form-control" name="nama" />

        <br/>
	
   <button type="submit" id="proceed" class="btn btn-primary" name="submit">Simpan</button>
<br/>
<br/>

		
    	</form>

			  
			  
			  

    	<br/>
      	<footer class="footer">
       
      	</footer>
    </div>
  	</body>

  
</html>

